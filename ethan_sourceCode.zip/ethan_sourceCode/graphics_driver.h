#ifndef GRAPHICS_DRIVER
#define GRAPHICS_DRIVER

void DrawBlock(int x_coord, int y_coord, bool remove);
void DrawSnake(int size, int x_coord, int y_coord);
void MoveBlock();
void Init_Map();
void Draw_Map();
#endif /* ADVENTURES_WITH_IP_H_ */
